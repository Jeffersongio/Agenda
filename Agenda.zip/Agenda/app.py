from flask import Flask, render_template, request, jsonify
from datetime import datetime

app = Flask(__name__)

# Simulando um banco de dados para reservas
reservas = {}

@app.route('/')
def index():
    return render_template('index.html', reservas=reservas)

@app.route('/reservar', methods=['POST'])
def reservar():
    data = request.json['data']
    nome = request.json['nome']
    turma = request.json['turma']
    computadores_selecionados = request.json['computadores']
    horario_inicio = request.json['horario_inicio']
    horario_fim = request.json['horario_fim']

    if data not in reservas:
        reservas[data] = []

    reservas[data].append({
        'nome': nome,
        'turma': turma,
        'computadores': computadores_selecionados,
        'horario_inicio': horario_inicio,
        'horario_fim': horario_fim
    })

    return jsonify({"message": "Reserva feita com sucesso!", "reservas": reservas[data]})

@app.route('/reservas/<data>', methods=['GET'])
def get_reservas(data):
    dia_reservas = reservas.get(data, [])
    horario_atual = datetime.now().time()

    # Marcar computadores como reservados com base no horário atual
    reservas_ativas = []
    for reserva in dia_reservas:
        inicio = datetime.strptime(reserva['horario_inicio'], '%H:%M').time()
        fim = datetime.strptime(reserva['horario_fim'], '%H:%M').time()

        if inicio <= horario_atual <= fim:
            reservas_ativas.append(reserva)

    return jsonify(reservas_ativas)

if __name__ == '__main__':
    app.run(debug=True)
