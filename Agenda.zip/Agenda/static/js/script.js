document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    const popup = document.getElementById('popup');
    const overlay = document.getElementById('popup-overlay');
    const fecharPopupBtn = document.getElementById('fechar-popup');
    const form = document.getElementById('reserva-form');
    const computadoresContainer = document.getElementById('computadores-container');

    let dataSelecionada = null;

    // Inicializa o calendário
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'pt-br',
        events: function(fetchInfo, successCallback, failureCallback) {
            fetch('/reservas/' + fetchInfo.startStr)
                .then(response => response.json())
                .then(data => {
                    const eventos = data.map(reserva => ({
                        title: `${reserva.nome} - PCs: ${reserva.computadores.length}`,
                        start: fetchInfo.startStr,
                    }));
                    successCallback(eventos);
                });
        },
        dateClick: function(info) {
            dataSelecionada = info.dateStr;
            abrirPopup();
        }
    });

    calendar.render();

    // Abrir pop-up
    function abrirPopup() {
        popup.style.display = 'block';
        overlay.style.display = 'block';
        gerarComputadores();
    }

    // Fechar pop-up
    fecharPopupBtn.addEventListener('click', function() {
        popup.style.display = 'none';
        overlay.style.display = 'none';
    });

    // Gerar computadores dinamicamente
    function gerarComputadores() {
        computadoresContainer.innerHTML = '';
        fetch(`/reservas/${dataSelecionada}`)
            .then(response => response.json())
            .then(reservas => {
                const reservados = reservas.flatMap(r => r.computadores);

                for (let i = 1; i <= 21; i++) {
                    const div = document.createElement('div');
                    div.className = 'computador';
                    div.textContent = i;
                    div.dataset.id = i;

                    if (reservados.includes(i.toString())) {
                        div.classList.add('reservado');
                    } else {
                        div.addEventListener('click', function() {
                            div.classList.toggle('selecionado');
                        });
                    }

                    computadoresContainer.appendChild(div);
                }
            });
    }

    // Submeter reserva
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const nome = document.getElementById('nome').value;
        const turma = document.getElementById('turma').value;
        const horarioInicio = document.getElementById('horario_inicio').value;
        const horarioFim = document.getElementById('horario_fim').value;
        const computadoresSelecionados = Array.from(document.querySelectorAll('.computador.selecionado'))
            .map(div => div.dataset.id);

        fetch('/reservar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                data: dataSelecionada,
                nome,
                turma,
                computadores: computadoresSelecionados,
                horario_inicio: horarioInicio,
                horario_fim: horarioFim
            })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            popup.style.display = 'none';
            overlay.style.display = 'none';
            calendar.refetchEvents();
        });
    });
});
