$(document).ready(function() {
    function carregarReservas() {
        $.get('/admin/reservas', function(reservas) {
            const tabela = $('#tabela-reservas tbody');
            tabela.empty();
            reservas.forEach(reserva => {
                const linha = `
                    <tr>
                        <td><input type="text" value="${reserva.nome}" data-id="${reserva.id}" class="input-nome"></td>
                        <td><input type="text" value="${reserva.turma}" data-id="${reserva.id}" class="input-turma"></td>
                        <td><input type="number" value="${reserva.num_computadores}" data-id="${reserva.id}" class="input-num-computadores"></td>
                        <td>${reserva.horario}</td>
                        <td>
                            <button class="btn-salvar" data-id="${reserva.id}">Salvar</button>
                            <button class="btn-excluir" data-id="${reserva.id}">Excluir</button>
                        </td>
                    </tr>`;
                tabela.append(linha);
            });
        }).fail(function() {
            alert('Erro ao carregar reservas.');
        });
    }

    // Carrega as reservas ao carregar a página
    carregarReservas();
});