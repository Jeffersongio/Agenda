from flask import Blueprint, render_template, jsonify, request

admin_bp = Blueprint('admin', __name__)
reservas = {}

@admin_bp.route('/admin')
def admin_dashboard():
    return render_template('admin.html')

@admin_bp.route('/admin/reservas', methods=['GET'])
def listar_reservas():
    lista_reservas = []
    for horario, reservas_horario in reservas.items():
        for i, reserva in enumerate(reservas_horario):
            lista_reservas.append({
                'id': f"{horario}-{i}",
                'horario': horario,
                'nome': reserva['nome'],
                'turma': reserva['turma'],
                'num_computadores': reserva['num_computadores']
            })
    return jsonify(lista_reservas)

@admin_bp.route('/admin/reservas/<reserva_id>', methods=['DELETE'])
def excluir_reserva(reserva_id):
    horario, index = reserva_id.rsplit('-', 1)
    index = int(index)
    if horario in reservas and 0 <= index < len(reservas[horario]):
        del reservas[horario][index]
        if not reservas[horario]:
            del reservas[horario]
        return jsonify({'status': 'sucesso'})
    return jsonify({'status': 'erro', 'mensagem': 'Reserva não encontrada'}), 404

@admin_bp.route('/admin/reservas/<reserva_id>', methods=['PUT'])
def modificar_reserva(reserva_id):
    horario, index = reserva_id.rsplit('-', 1)
    index = int(index)
    if horario in reservas and 0 <= index < len(reservas[horario]):
        dados = request.json
        reservas[horario][index].update({
            'nome': dados.get('nome', reservas[horario][index]['nome']),
            'turma': dados.get('turma', reservas[horario][index]['turma']),
            'num_computadores': dados.get('num_computadores', reservas[horario][index]['num_computadores']),
        })
        return jsonify({'status': 'sucesso'})
    return jsonify({'status': 'erro', 'mensagem': 'Reserva não encontrada'}), 404