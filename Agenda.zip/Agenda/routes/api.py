from flask import Blueprint, jsonify, request

api_bp = Blueprint('api', __name__)

LIMITE_COMPUTADORES = 21  # Total de computadores disponíveis
reservas = {}  # Estrutura para armazenar as reservas

def obter_computadores_ocupados(horario):
    """
    Retorna uma lista de IDs de computadores já reservados no horário especificado.
    """
    if horario not in reservas:
        return []
    
    # Combina todos os computadores reservados para o horário
    return [
        computador for reserva in reservas[horario] for computador in reserva['computadores']
    ]

@api_bp.route('/reservar', methods=['POST'])
def reservar():
    """
    Rota para criar uma nova reserva.
    """
    try:
        nome = request.json['nome']  # Altere para .json
        turma = request.json['turma']  # Altere para .json
        num_computadores = int(request.json['num_computadores'])  # Altere para .json
        horario = request.json['horario']  # Altere para .json

        # Garantir que o horário existe na estrutura
        if horario not in reservas:
            reservas[horario] = []

        # Obter computadores já reservados no horário
        computadores_reservados = obter_computadores_ocupados(horario)

        # Verificar se há computadores disponíveis suficientes
        if len(computadores_reservados) + num_computadores > LIMITE_COMPUTADORES:
            return jsonify({'status': 'erro', 'mensagem': 'Quantidade excede o limite disponível.'}), 400

        # Determinar quais computadores serão reservados
        computadores_disponiveis = [i for i in range(1, LIMITE_COMPUTADORES + 1) if i not in computadores_reservados]
        computadores_a_reservar = computadores_disponiveis[:num_computadores]

        # Salvar a nova reserva
        reservas[horario].append({
            'nome': nome,
            'turma': turma,
            'computadores': computadores_a_reservar
        })

        return jsonify({
            'status': 'sucesso',
            'computadores': computadores_a_reservar,
            'mensagem': f'Reserva realizada com sucesso para os computadores: {", ".join(map(str, computadores_a_reservar))}'
        })

    except Exception as e:
        return jsonify({'status': 'erro', 'mensagem': str(e)}), 500  # Tratamento de erros
